// scripts.js - Custom JavaScript for Galiwango Hussein's Portfolio

document.addEventListener('DOMContentLoaded', function() {
  // Set current year in footers
  const currentYear = new Date().getFullYear();
  document.getElementById('year').textContent = currentYear;
  if (document.getElementById('year2')) document.getElementById('year2').textContent = currentYear;
  if (document.getElementById('year3')) document.getElementById('year3').textContent = currentYear;
  if (document.getElementById('year4')) document.getElementById('year4').textContent = currentYear;

  // Scroll to top button functionality
  const scrollTopBtn = document.getElementById('scrollTopBtn');
  if (scrollTopBtn) {
    window.addEventListener('scroll', function() {
      if (window.pageYOffset > 100) {
        scrollTopBtn.style.display = 'block';
      } else {
        scrollTopBtn.style.display = 'none';
      }
    });

    scrollTopBtn.addEventListener('click', function() {
      window.scrollTo({ top: 0, behavior: 'smooth' });
    });
  }

  // Contact form validation and submission
  const contactForm = document.getElementById('contactForm');
  if (contactForm) {
    contactForm.addEventListener('submit', function(event) {
      event.preventDefault();
      if (!contactForm.checkValidity()) {
        event.stopPropagation();
        contactForm.classList.add('was-validated');
        return;
      }

      // Simulate form submission (in a real app, send to server)
      const name = document.getElementById('name').value;
      const email = document.getElementById('email').value;
      const message = document.getElementById('message').value;

      alert(`Thank you, ${name}! Your message has been sent. We'll get back to you at ${email} soon.`);

      // Reset form
      contactForm.reset();
      contactForm.classList.remove('was-validated');
    });
  }

  // Project modal functionality
  const projectModal = document.getElementById('projectModal');
  const projectModalBody = document.getElementById('projectModalBody');

  if (projectModal && projectModalBody) {
    document.addEventListener('click', function(event) {
      if (event.target.matches('[data-bs-toggle="modal"][data-project]')) {
        const projectId = event.target.getAttribute('data-project');
        let content = '';

        switch (projectId) {
          case '1':
            content = `
              <h4>Responsive Portfolio (This Site)</h4>
              <p>This multi-page portfolio showcases responsive design using Bootstrap 5, custom CSS, and JavaScript for interactivity.</p>
              <ul>
                <li>HTML5 semantic structure</li>
                <li>CSS3 animations and gradients</li>
                <li>JavaScript for dynamic content</li>
                <li>Bootstrap 5 components</li>
              </ul>
              <img src="assets/project1.jpg" alt="Portfolio Preview" class="img-fluid rounded">
            `;
            break;
          case '2':
            content = `
              <h4>Library Management Mock</h4>
              <p>A prototype UI for a library management system demonstrating CRUD operations and responsive tables.</p>
              <ul>
                <li>Responsive table layouts</li>
                <li>Form validation</li>
                <li>Modal dialogs for CRUD</li>
                <li>Bootstrap grid system</li>
              </ul>
              <img src="assets/project2.jpg" alt="Library Mock Preview" class="img-fluid rounded">
            `;
            break;
          case '3':
            content = `
              <h4>Media Gallery</h4>
              <p>An image and video gallery with lightbox-style modals and filtering capabilities.</p>
              <ul>
                <li>Lightbox modal implementation</li>
                <li>Media filtering UI</li>
                <li>Responsive image grids</li>
                <li>Video embedding</li>
              </ul>
              <img src="assets/project3.jpg" alt="Gallery Preview" class="img-fluid rounded">
            `;
            break;
          default:
            content = '<p>Project details not available.</p>';
        }

        projectModalBody.innerHTML = content;
      }
    });
  }

  // Smooth scrolling for anchor links
  document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function (e) {
      e.preventDefault();
      const target = document.querySelector(this.getAttribute('href'));
      if (target) {
        target.scrollIntoView({
          behavior: 'smooth'
        });
      }
    });
  });

  // Navbar collapse on link click (mobile)
  const navLinks = document.querySelectorAll('.navbar-nav .nav-link');
  const navbarCollapse = document.querySelector('.navbar-collapse');

  navLinks.forEach(link => {
    link.addEventListener('click', () => {
      if (navbarCollapse.classList.contains('show')) {
        const bsCollapse = new bootstrap.Collapse(navbarCollapse, {
          hide: true
        });
      }
    });
  });
});
